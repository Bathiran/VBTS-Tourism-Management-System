package booking;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/createpackage")
public class create_package extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String PackageName=request.getParameter("package_name");
		String PackageType=request.getParameter("package_type");
		String PackageLocation=request.getParameter("package_location");
		String PackagePrice=request.getParameter("package_price");
		String PackageFetures=request.getParameter("package_features");
		String PackageDetails=request.getParameter("package_details");
		String PackageImage=request.getParameter("package_image");
		
		RequestDispatcher dispatcher=null;
		Connection con=null;
		
		
		if(PackageName==null||PackageName.equals("")) {
			request.setAttribute("status", "invalidPackageName");
			dispatcher=request.getRequestDispatcher("create_package.jsp");
			dispatcher.forward(request, response);
		}
		if(PackageType==null||PackageType.equals("")) {
			request.setAttribute("status", "invalidPackageType");
			dispatcher=request.getRequestDispatcher("create_package.jsp");
			dispatcher.forward(request, response);
		}
		if(PackageLocation==null||PackageLocation.equals("")) {
			request.setAttribute("status", "invalidPackageLocation");
			dispatcher=request.getRequestDispatcher("create_package.jsp");
			dispatcher.forward(request, response);
		}
		if(PackagePrice==null||PackagePrice.equals("")) {
			request.setAttribute("status", "invalidpackageprice");
			dispatcher=request.getRequestDispatcher("create_package.jsp");
			dispatcher.forward(request, response);
		}
		if(PackageFetures==null||PackageFetures.equals("")) {
			request.setAttribute("status", "invalidPackageFetures");
			dispatcher=request.getRequestDispatcher("create_package.jsp");
			dispatcher.forward(request, response);
		}
		if(PackageDetails==null||PackageDetails.equals("")) {
			request.setAttribute("status", "invalidPackageDetails");
			dispatcher=request.getRequestDispatcher("create_package.jsp");
			dispatcher.forward(request, response);
		}
		if(PackageImage==null||PackageImage.equals("")) {
			request.setAttribute("status", "invalidPackageImage");
			dispatcher=request.getRequestDispatcher("create_package.jsp");
			dispatcher.forward(request, response);
		}
		
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/jaffna?useSSL=false","root","");
			PreparedStatement pst=con.prepareStatement("insert into tourpackages(PackageName,PackageType,PackageLocation,PackagePrice,PackageFetures,PackageDetails,PackageImage)values(?,?,?,?,?,?,?)");
			pst.setString(1, PackageName);
			pst.setString(2, PackageType);
			pst.setString(3, PackageLocation);
			pst.setString(4, PackagePrice);
			pst.setString(5, PackageFetures);
			pst.setString(6, PackageDetails	);
			pst.setString(7, PackageImage);
			
			int rowCount=pst.executeUpdate();
			dispatcher=request.getRequestDispatcher("create_package.jsp");
					
			if(rowCount>0) {
				request.setAttribute("status", "success");
			}else {
				request.setAttribute("status", "failed");
			}
			
			dispatcher.forward(request, response);
		}catch(Exception e) {
			e.printStackTrace();
			
		}finally {
			try {
				con.close();
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

		
		
	

}
